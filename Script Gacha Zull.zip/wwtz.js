import fs from 'fs-extra';
import path from 'path';
import archiver from "archiver";
import { fileURLToPath } from 'url';
import { nanoid } from 'nanoid';
import config from './config.js'; 
import { Parser } from 'json2csv';
import schedule from 'node-schedule';
import fetch from "node-fetch";
import chalk from "chalk";
import os from 'os';
import si from 'systeminformation';
import TelegramBot from 'node-telegram-bot-api'; 

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDir = path.join(__dirname, 'data');
const dataFiles = ['items.json', 'users.json', 'gacha_codes.json', 'referrals.json', 'chats.json', 'blacklist.json', 'codes.json']; // 💡 TAMBAH CODES.JSON

// ... (Bagian setup data directory) ...

// --- Inisialisasi Bot ---
const bot = new TelegramBot(config.BOT_TOKEN, { polling: true }); // INI HARUS ADA

const loadData = (file) => {
  try {
    const filePath = path.join(dataDir, file);
    // Cek jika file baru, inisialisasi dengan array kosong
    if (!fs.existsSync(filePath)) {
      if (file === 'codes.json' || file === 'blacklist.json' || file === 'users.json' || file === 'chats.json') {
         return [];
      } else {
         return [];
      }
    }
    return fs.readJsonSync(filePath);
  } catch (e) {
    console.error(`[LOAD DATA ERROR] Gagal membaca ${file}: ${e.message}`);
    // Return array kosong untuk file yang seharusnya berisi array
    return [];
  }
};
const saveData = (file, data) => {
  try {
    fs.writeJsonSync(path.join(dataDir, file), data, { spaces: 2 });
  } catch (e) {
    console.error(`[SAVE DATA ERROR] Gagal menulis ke ${file}: ${e.message}`);
  }
};

const cooldown = new Map();
const COOLDOWN_TIME = 40000;
const welcomeAudio = path.join(__dirname, 'BotGachaPremium.mp3');

// --- Inisialisasi Admin di Memori ---
// ⚠️ ADMIN_IDS dari config.js hanya dimuat saat bot start. Tidak disarankan diubah live.
let ADMIN_IDS = config.ADMIN_IDS || []; 

// 💡 VARIABEL BARU UNTUK KODE REDEEM
let codes = loadData('codes.json');
const EXPIRATION_MINUTES = 60; // Default 60 menit

// --- Helper Subscription Check ---
async function isUserSubscribed(userId) {
  if (!config.CHANNEL_ID) return true; // Lewati jika CHANNEL_ID tidak diset
  try {
    const m = await bot.getChatMember(config.CHANNEL_ID, userId);
    return ['member', 'administrator', 'creator'].includes(m.status);
  } catch (e) {
    // 400 Bad Request (user not in chat) atau 403 Forbidden (bot tidak diizinkan di channel)
    return false;
  }
}

// === Safe Send Message (versi aman dengan rate limit handling) ===
async function safeSendMessage(chatId, text, options = {}) {
  try {
    const sent = await bot.sendMessage(chatId, text, options);
    return sent;
  } catch (err) {
    if (err.response && err.response.statusCode === 429) {
      const retryAfter = (err.response.parameters?.retry_after || 1) * 1000;
      console.log(chalk.yellow(`⚠️ Rate limit hit. Retry after ${retryAfter}ms for ${chatId}`));
      await new Promise(r => setTimeout(r, retryAfter));
      return await safeSendMessage(chatId, text, options); // Rekursif
    } else if (err.response?.body?.error_code === 403 && /bot was blocked/i.test(err.message)) {
      console.log(chalk.red(`❌ User ${chatId} blokir bot, dilewati.`));
    } else {
      console.error(chalk.red(`❌ Gagal kirim pesan ke ${chatId}:`), err.message);
    }
    return null;
  }
}

// ------------------------------------------------------------------
//                             COMMANDS
// ------------------------------------------------------------------

bot.onText(/\/start(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const inviterId = match[1] ? Number(match[1]) : null;
  let users = loadData('users.json');
  const today = new Date().toDateString();
  let isNewUser = false;

  if (msg.chat.type !== 'private') return;
  if (msg.from?.is_bot) return;
  if (String(chatId).startsWith('-100')) return;

  let user = users.find(u => u.id === chatId);
  if (!user) {
    // 💡 TAMBAH redeemedCodes: []
    user = { id: chatId, gachaToday: 0, bonus: 0, history: [], lastDate: today, extraLimit: 0, redeemedCodes: [] };
    users.push(user);
    isNewUser = true;
  } else if (user.lastDate !== today) {
    user.gachaToday = 0;
    user.extraLimit = 0;
    user.lastDate = today;
  }
  // 💡 INIT redeemedCodes jika belum ada
  if (!Array.isArray(user.redeemedCodes)) user.redeemedCodes = [];


  // --- Referral Logic ---
  if (inviterId && inviterId !== chatId) {
    const refs = loadData('referrals.json');
    if (!refs.find(r => r.invited === chatId)) {
      refs.push({ inviter: inviterId, invited: chatId, date: new Date() });
      saveData('referrals.json', refs);

      let inviter = users.find(u => u.id === inviterId);
      if (inviter) inviter.bonus = (Number(inviter.bonus) || 0) + 1;
      else users.push({ id: inviterId, gachaToday: 0, bonus: 1, history: [], lastDate: today, extraLimit: 0, redeemedCodes: [] });

      await safeSendMessage(inviterId,
        `✨ 𝗕𝗢𝗡𝗨𝗦 𝗥𝗘𝗙𝗘𝗥𝗥𝗔𝗟 ✨\n\n🎁 Teman baru telah bergabung lewat link referralmu!\n🪄 Bonus *1x Gacha* telah ditambahkan ke akunmu secara otomatis.\n\n💎 Semakin banyak teman yang bergabung, semakin tinggi hadiah eksklusifmu!\n🌟 Nikmati keistimewaanmu sebagai member premium.`,
        { parse_mode: 'Markdown' });
    }
  }

  // --- New User Notification (Admin) ---
  if (isNewUser) {
    const username = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;
    const totalUsers = users.length.toLocaleString("id-ID");
    const joinTime = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

    for (const adminId of ADMIN_IDS) {
      await safeSendMessage(
        adminId,
        `💠 *User Baru Bergabung!*
━━━━━━━━━━━━━━━━━━━
👤 *Nama:* ${msg.from.first_name}
🏷️ *Username:* ${msg.from.username ? `@${msg.from.username}` : "—"}
🆔 *User ID:* \`${chatId}\`
⏰ *Waktu:* ${joinTime}
━━━━━━━━━━━━━━━━━━━
📊 *Total Pengguna Sekarang:* ${totalUsers} user
━━━━━━━━━━━━━━━━━━━
🚀 _Pantau pertumbuhan komunitas premiummu secara real-time!_`,
        { parse_mode: "Markdown" }
      );
    }
  }

  saveData('users.json', users); // Simpan semua perubahan (termasuk referral dan reset harian)

  // === Prepare Welcome Message Data ===
  const totalLimit = config.GACHA_LIMIT || 5;
  const sisaLimit = Math.max(totalLimit - user.gachaToday, 0);
  const usedBonus = Math.max(user.gachaToday - totalLimit, 0);
  const sisaBonus = Math.max(user.bonus - usedBonus, 0);
  const chats = loadData('chats.json'); // chats.json
  const totalUsers = users.length;
  const totalGrups = chats.length;

  const banner = 'https://files.catbox.moe/y5ny8h.jpg';
  const caption = `
\`\`\`
sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ʙᴏᴛ ɢᴀᴄʜᴀ ᴘʀᴇᴍɪᴜᴍ
╭───────────────╾
│  ├─ ᴀᴜᴛʜᴏʀ: @theoneowned
│  ├─ ᴠᴇʀsɪᴏɴ ʙᴏᴛ: 𝟸.𝟶 
│  ├─────────────╾
│  ├─ ʟɪᴍɪᴛ ɢᴀᴄʜᴀ: ${sisaLimit}
│  ├─ ʙᴏɴᴜs ᴋᴀᴍᴜ: ${sisaBonus}
│  ├─ ᴘᴇɴɢɢᴜɴᴀ ʙᴏᴛ: ${totalUsers}
│  └─ ᴛᴏᴛᴀʟ ɢʀᴜʙ: ${totalGrups}
╰────────────────╾
╭────────────────╾
│
├ /ɢᴀᴄʜᴀ - ɢᴀᴄʜᴀ ʀᴀɴᴅᴏᴍ
├ /ʜɪsᴛᴏʀʏ - ᴄᴇᴋ ʜɪsᴛᴏʀʏ ɢᴀᴄʜᴀ
├ /ʟɪsᴛɪᴛᴇᴍ - ᴅᴀғᴛᴀʀ ɪᴛᴇᴍ
├ /ʀᴇᴅᴇᴇᴍ - ᴄᴏᴅᴇ ᴍᴇɴᴀᴍʙᴀʜ ʟɪᴍɪᴛ
├ /ᴍʏsᴛᴀᴛ - ɪɴғᴏ ᴋᴀᴍᴜ
├ /ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ - ᴛᴏᴘ ɢᴀᴄʜᴀ
├ /ᴄᴇᴋɪᴅ - ɪᴅ ᴋᴀᴍᴜ
├ /ᴘɪɴɢ - ᴄᴇᴋ ᴘɪɴɢ sᴇʀᴠᴇʀ
│
╰────────────────╾
ɪɴᴠɪᴛᴇ ᴛᴇᴍᴀɴ ᴅᴀɴ ᴅᴀᴘᴀᴛᴋᴀɴ ʙᴏɴᴜs 𝟷x ɢᴀᴄʜᴀ
ᴀᴅᴅ ʙᴏᴛ ᴋᴇ ɢʀᴜʙ ʙᴏɴᴜs 𝟸x ɢᴀᴄʜᴀ
\`\`\`
`;

  const keyboard = [
    [
      { text: "ɪɴᴠɪᴛᴇ ᴛᴇᴍᴀɴ", callback_data: "undang_teman" },
      { text: "ᴀᴅᴅ ʙᴏᴛ ᴋᴇ ɢʀᴜʙ", url: `https://t.me/${config.BOT_USERNAME}?startgroup=true` }
    ],
    [
      { text: "ᴄʜᴀɴɴᴇʟ", url: `https://t.me/${config.CHANNEL_ID.replace('@', '')}` }
    ],
    [
      { text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "owner_menu" },
      { text: "ᴅᴇᴠᴇʟᴏᴘᴇʀ", url: `https://t.me/${config.OWNER_USERNAME}` }
    ]
  ];

  await bot.sendPhoto(chatId, banner, {
    caption,
    parse_mode: 'Markdown',
    reply_markup: { inline_keyboard: keyboard }
  }).catch(e => console.error("Gagal kirim foto welcome:", e.message));

  if (fs.existsSync(welcomeAudio)) {
    await bot.sendAudio(chatId, welcomeAudio, { caption: "🎧 Welcome ke Bot Gacha Premium!" }).catch(e => console.error("Gagal kirim audio welcome:", e.message));
  }
});

// === CALLBACK HANDLER ===
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const isAdmin = ADMIN_IDS.includes(query.from.id);

  if (query.data === 'owner_menu') {
    if (!isAdmin) {
      await bot.answerCallbackQuery(query.id, { text: '⚠️ Kamu tidak memiliki akses ke Owner Menu', show_alert: true });
      return;
    }

    const users = loadData('users.json');
    const chats = loadData('chats.json');

    const user = users.find(u => u.id === query.from.id) || {};

    const totalLimit = config.GACHA_LIMIT || 5;
    const sisaLimit = Math.max(totalLimit - (user.gachaToday || 0), 0);
    const sisaBonus = user.bonus || 0;
    const totalUsers = users.length || 0;
    const totalGrups = chats.length || 0;

    const ownerCaption = `
\`\`\`
sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ʙᴏᴛ ɢᴀᴄʜᴀ ᴘʀᴇᴍɪᴜᴍ
╭───────────────╾
│  ├─ ᴀᴜᴛʜᴏʀ: @theoneowned
│  ├─ ʟɪᴍɪᴛ ɢᴀᴄʜᴀ: ${sisaLimit}
│  ├─ ʙᴏɴᴜs ᴋᴀᴍᴜ: ${sisaBonus}
│  ├─ ᴘᴇɴɢɢᴜɴᴀ ʙᴏᴛ: ${totalUsers}
│  └─ ᴛᴏᴛᴀʟ ɢʀᴜʙ: ${totalGrups}
╰────────────────╾
╭────────────────╾
│
├ /ᴀᴅᴅʟɪᴍɪᴛ - ᴀᴅᴅʟɪᴍɪᴛ ᴜsᴇʀ
├ /ʜᴀᴘᴜsʟɪᴍɪᴛ - ʜᴀᴘᴜs ʟɪᴍɪᴛ ʙᴏɴᴜs
├ /ᴀᴅᴅʟɪᴍɪᴛᴀʟʟ - ʙᴏɴᴜs ᴍᴀssᴀʟ
├ /ᴄʀᴇᴀᴛᴇᴄᴏᴅᴇ - ᴍᴀᴋᴇ ʀᴇᴅᴇᴇᴍ ᴄᴏᴅᴇ 
├ /ᴀᴅᴅɪᴛᴇᴍ - ᴛᴀᴍʙᴀʜ ɪᴛᴇᴍ ɢᴀᴄʜᴀ
├ /ᴅᴇʟɪᴛᴇᴍ - ʜᴀᴘᴜs ɪᴛᴇᴍ ɢᴀᴄʜᴀ
├ /ᴄʟᴇᴀʀɪᴛᴇᴍs - ʜᴀᴘᴜs sᴇᴍᴜᴀ ɪᴛᴇᴍ
├ /ʙᴀᴄᴋᴜᴘ - ʙᴀᴄᴋᴜᴘ ᴅᴀᴛᴀ
├ /ʙʟᴀᴄᴋʟɪsᴛ - ʙʟᴀᴄᴋʟɪsᴛ ᴜsᴇʀ
├ /ᴅᴇʟʙʟᴀᴄᴋʟɪsᴛ - ʜᴀᴘᴜs ʙʟᴀᴄᴋʟɪsᴛ
├ /ʟɪsᴛʙʟᴀᴄᴋʟɪsᴛ - ʟɪsᴛ ʙʟᴀᴄᴋʟɪsᴛ
├ /ʟɪsᴛᴀᴅᴍɪɴ - ʟɪsᴛ ᴀʟʟ ᴀᴅᴍɪɴ
├ /ʙᴄɢʀᴜʙ - ʙʀᴏᴀᴅᴄᴀsᴛ ᴋᴇ ɢʀᴜʙ
├ /ʙʀᴏᴀᴅᴄᴀsᴛ - ᴘᴇɴɢᴜᴍᴜᴍᴀɴ ᴜsᴇʀ
├ /ᴄʜᴇᴄᴋsᴛᴀᴛ - ᴄᴇᴋ ᴀᴋᴛɪᴠɪᴛᴀs ᴜsᴇʀ
│
╰────────────────╾
\`\`\`
`;

    const ownerKeyboard = [
      [{ text: "ᴋᴇᴍʙᴀʟɪ", callback_data: "main_menu" }]
    ];

    await bot.editMessageCaption(ownerCaption, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: ownerKeyboard }
    }).catch(e => console.error("Gagal edit owner menu:", e.message));

  } else if (query.data === 'main_menu') {
    const users = loadData('users.json');
    const user = users.find(u => u.id === chatId) || { gachaToday: 0, bonus: 0 };
    const chats = loadData('chats.json');
    const totalUsers = users.length;
    const totalGrups = chats.length;
    const totalLimit = config.GACHA_LIMIT || 5;
    const sisaLimit = Math.max(totalLimit - user.gachaToday, 0);
    const usedBonus = Math.max(user.gachaToday - totalLimit, 0);
    const sisaBonus = Math.max(user.bonus - usedBonus, 0);

    const banner = 'https://files.catbox.moe/y5ny8h.jpg';
    const caption = `
\`\`\`
sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ʙᴏᴛ ɢᴀᴄʜᴀ ᴘʀᴇᴍɪᴜᴍ
╭───────────────╾
│  ├─ ᴀᴜᴛʜᴏʀ: @theoneowned
│  ├─ ʟɪᴍɪᴛ ɢᴀᴄʜᴀ: ${sisaLimit}
│  ├─ ʙᴏɴᴜs ᴋᴀᴍᴜ: ${sisaBonus}
│  ├─ ᴘᴇɴɢɢᴜɴᴀ ʙᴏᴛ: ${totalUsers}
│  └─ ᴛᴏᴛᴀʟ ɢʀᴜʙ: ${totalGrups}
╰────────────────╾
╭────────────────╾
│
├ /ɢᴀᴄʜᴀ ☇ ɢᴀᴄʜᴀ ʀᴀɴᴅᴏᴍ
├ /ʜɪsᴛᴏʀʏ ☇ ᴄᴇᴋ ʜɪsᴛᴏʀʏ ɢᴀᴄʜᴀ
├ /ʟɪsᴛɪᴛᴇᴍ ☇ ᴅᴀғᴛᴀʀ ɪᴛᴇᴍ ɢᴀᴄʜᴀ
├ /ʀᴇᴅᴇᴇᴍ - ᴄᴏᴅᴇ ᴍᴇɴᴀᴍʙᴀʜ ʟɪᴍɪᴛ
├ /ᴍʏsᴛᴀᴛ ☇ ɪɴғᴏ ᴋᴀᴍᴜ
├ /ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ ☇ ᴛᴏᴘ ɢᴀᴄʜᴀ
│
╰────────────────╾
ɪɴᴠɪᴛᴇ ᴛᴇᴍᴀɴ ᴅᴀɴ ᴅᴀᴘᴀᴛᴋᴀɴ ʙᴏɴᴜs 𝟷x ɢᴀᴄʜᴀ
ᴀᴅᴅ ʙᴏᴛ ᴋᴇ ɢʀᴜʙ ʙᴏɴᴜs 𝟷x ɢᴀᴄʜᴀ
\`\`\`
`;

    const keyboard = [
      [
        { text: "ɪɴᴠɪᴛᴇ ᴛᴇᴍᴀɴ", callback_data: "undang_teman" },
        { text: "ᴀᴅᴅ ʙᴏᴛ ᴋᴇ ɢʀᴜʙ", url: `https://t.me/${config.BOT_USERNAME}?startgroup=true` }
      ],
      [
        { text: "ᴄʜᴀɴɴᴇʟ", url: `https://t.me/${config.CHANNEL_ID.replace('@', '')}` }
      ],
      [
        { text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "owner_menu" },
        { text: "ᴅᴇᴠᴇʟᴏᴘᴇʀ", url: `https://t.me/${config.OWNER_USERNAME}` }
      ]
    ];

    await bot.editMessageMedia(
      { type: 'photo', media: banner, caption, parse_mode: 'Markdown' },
      { chat_id: chatId, message_id: messageId }
    ).catch(e => console.error("Gagal edit media main menu:", e.message));

    await bot.editMessageReplyMarkup(
      { inline_keyboard: keyboard },
      { chat_id: chatId, message_id: messageId }
    ).catch(e => console.error("Gagal edit reply markup main menu:", e.message));
  } else if (query.data === 'undang_teman') {
    const referralLink = `https://t.me/${config.BOT_USERNAME}?start=${query.from.id}`;
    await bot.answerCallbackQuery(query.id);

    await safeSendMessage(query.from.id, `
\`\`\`   
✨ 𝗥𝗘𝗙𝗘𝗥𝗥𝗔𝗟 𝗕𝗢𝗡𝗨𝗦 ✨

🚀 Ajak teman-temanmu bergabung dan raih *hadiah spesial* setiap kali mereka mulai lewat link kamu!

💎 Semakin banyak teman yang join, semakin besar hadiahnya!

🔗 ${referralLink}
\`\`\`
    `, { parse_mode: "Markdown" });
  }
});

// === RESET OTOMATIS TIAP HARI ===  
schedule.scheduleJob({ hour: 0, minute: 0, tz: 'Asia/Jakarta' }, () => {
  let users = loadData('users.json');
  const today = new Date().toDateString();

  users = users.map(u => ({
    ...u,
    gachaToday: 0,
    extraLimit: 0, // Pastikan extraLimit juga direset
    lastDate: today
  }));

  saveData('users.json', users);
  console.log(chalk.blue(`[RESET OTOMATIS] Limit gacha direset (${today})`));

  for (const adminId of ADMIN_IDS) {
    safeSendMessage(adminId, `✅ Limit gacha harian telah direset otomatis (${today})`);
  }
});

bot.onText(/\/gacha/, async (msg) => {
  const userId = Number(msg.from.id);

  // === Cek blacklist ===
  const blacklist = loadData('blacklist.json');
  if (blacklist.includes(userId)) {
    return safeSendMessage(userId, "🚫 Kamu diblok dari menggunakan gacha. Hubungi admin jika ini kesalahan.");
  }

  if (msg.chat.type !== 'private') {
    return safeSendMessage(userId, '⚠️ Gacha hanya bisa dilakukan di chat pribadi dengan bot.');
  }

  // === Anti-Spam Cooldown ===
  const lastUse = cooldown.get(userId);
  const now = Date.now();
  if (lastUse && now - lastUse < COOLDOWN_TIME) {
    const remaining = ((COOLDOWN_TIME - (now - lastUse)) / 1000).toFixed(1);
    return safeSendMessage(userId, `🕐 Tunggu ${remaining} detik sebelum gacha lagi.`);
  }
  cooldown.set(userId, now);

  // === Wajib follow channel ===
  if (config.CHANNEL_ID && !await isUserSubscribed(userId)) {
    return safeSendMessage(
      userId,
      `⚠️ Kamu harus follow channel untuk gacha.\n👉 [Join Channel](https://t.me/${config.CHANNEL_ID.replace('@', '')})`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: "📢 Join Channel", url: `https://t.me/${config.CHANNEL_ID.replace('@', '')}` }]
          ]
        }
      }
    );
  }

  // --- Load and Initialize User Data ---
  let users = loadData('users.json');
  let gachaCodes = loadData('gacha_codes.json');
  const today = new Date().toDateString();

  let user = users.find(u => Number(u.id) === userId);

  if (!user) {
    // 💡 TAMBAH redeemedCodes
    user = { id: userId, gachaToday: 0, bonus: 0, extraLimit: 0, history: [], lastDate: today, redeemedCodes: [] };
    users.push(user);
  }

  // Reset harian
  if (user.lastDate !== today) {
    user.gachaToday = 0;
    user.extraLimit = 0;
    user.lastDate = today;
  }
  // 💡 INIT redeemedCodes jika belum ada
  if (!Array.isArray(user.redeemedCodes)) user.redeemedCodes = [];


  // === Hitung total kesempatan ===
  const dailyLimit = config.GACHA_LIMIT || 0;
  // 💡 extraLimit adalah limit tambahan dari kode redeem
  const totalLimit = dailyLimit + (user.extraLimit || 0); 
  const sisaLimit = Math.max(totalLimit - user.gachaToday, 0);
  const sisaBonus = Math.max(user.bonus, 0);
  const totalKesempatan = sisaLimit + sisaBonus;

  if (totalKesempatan <= 0) {
    return safeSendMessage(
      userId,
      `❌ *Limit Harian Habis!* (Limit: ${dailyLimit}, Extra: ${user.extraLimit || 0}, Bonus: ${user.bonus || 0})\nKamu sudah menggunakan semua kesempatan hari ini.\n\n🎁 Invite teman atau add bot ke grup untuk dapat bonus gacha, atau tunggu reset besok.`,
      { parse_mode: "Markdown" }
    );
  }

  // === Tentukan sumber gacha & KURANGI KESEMPATAN ===
  let sumber = "Limit";
  if (sisaLimit > 0) {
    user.gachaToday++;
    // 💡 KURANGI extraLimit jika limit harian dari config sudah habis, tapi extraLimit masih ada.
    // Jika limit harian (config.GACHA_LIMIT) habis, dan gachaToday > config.GACHA_LIMIT,
    // maka pemakaian gachaToday selanjutnya adalah dari extraLimit
    if ((user.gachaToday - dailyLimit) > 0) {
        user.extraLimit = Math.max(0, (user.extraLimit || 0) - 1);
        sumber = "ExtraLimit";
    } else {
        sumber = "Limit";
    }

  } else if (user.bonus > 0) {
    user.bonus--; // bonus langsung terpakai
    sumber = "Bonus";
  }


  // --- ANIMASI LOADING ---
  const barMsg = await safeSendMessage(userId, "🎰 *Menyiapkan sistem gacha...*\n[▒▒▒▒▒▒▒▒▒▒] 0%", { parse_mode: "Markdown" });
  if (barMsg) {
    for (let i = 1; i <= 10; i++) {
      await new Promise(r => setTimeout(r, 150));
      const bar = '█'.repeat(i) + '▒'.repeat(10 - i);
      await bot.editMessageText(`🎰 *Menyiapkan sistem gacha...*\n[${bar}] ${i * 10}%`, {
        chat_id: userId,
        message_id: barMsg.message_id,
        parse_mode: "Markdown"
      }).catch(() => {}); // catch error jika user hapus pesan
    }
    await bot.deleteMessage(userId, barMsg.message_id).catch(() => {});
  }

  // === Pilih item acak ===
  const items = loadData('items.json');
  if (!items.length) {
    // Kembalikan limit jika tidak ada item
    if (sumber === "Limit") user.gachaToday--;
    else if (sumber === "ExtraLimit") user.extraLimit = (user.extraLimit || 0) + 1; // Kembalikan ExtraLimit
    else if (sumber === "Bonus") user.bonus++;
    saveData('users.json', users); // Simpan kembali sebelum keluar
    return safeSendMessage(userId, '📭 Belum ada item gacha.');
  }

  const item = items[Math.floor(Math.random() * items.length)];
  const code = nanoid(6).toUpperCase();

  // === Update History dan Code Database ===
  user.history.push({ item: item.name, code, date: new Date(), sumber });
  gachaCodes.push({ userId, item: item.name, code, date: new Date(), sumber });

  saveData('users.json', users); // Simpan sekali di akhir
  saveData('gacha_codes.json', gachaCodes);

  // Re-hitung sisa limit
  const sisaLimitNow = Math.max(dailyLimit - user.gachaToday, 0);
  const sisaExtraLimitNow = Math.max(user.extraLimit, 0);
  const sisaBonusNow = Math.max(user.bonus, 0);

  // === Hasil Gacha ===
  await safeSendMessage(
    userId,
    `\`\`\`
🎰 ɢᴀᴄʜᴀ sᴇʟᴇsᴀɪ!

🎁 ʜᴀᴅɪᴀʜ : ${item.name}
🧭 sᴜᴍʙᴇʀ : ${sumber}
🎟 ᴋᴏᴅᴇ   : ${code}
────────────────────
📊 ʟɪᴍɪᴛ ᴛᴇʀsɪsᴀ : ${sisaLimitNow}
⚡ ᴇxᴛʀᴀ ʟɪᴍɪᴛ  : ${sisaExtraLimitNow} 💡
💎 ʙᴏɴᴜꜱ ᴛᴇʀsɪsᴀ : ${sisaBonusNow}
\`\`\``,
    { parse_mode: 'Markdown' }
  );

  if (item.filename) {
    const filePath = path.join(dataDir, item.filename);
    if (fs.existsSync(filePath)) {
      await bot.sendDocument(userId, filePath, { caption: `💎 ʜᴀᴅɪᴀʜ: *${item.name}*`, parse_mode: "Markdown" }).catch(e => console.error("Gagal kirim dokumen gacha:", e.message));
    }
  }

  // === 👾 Console Log ===
  const time = new Date().toLocaleTimeString("id-ID");
  console.log(chalk.hex("#00FF00")("┌──────────────────────────────────────────────┐"));
  console.log(chalk.hex("#32CD32")(`│ [${time}] SYSTEM: GACHA.EXE EXECUTED        │`));
  console.log(chalk.hex("#00FF00")("├──────────────────────────────────────────────┤"));
  console.log(`${chalk.hex("#7FFF00")("USER")}   → ${chalk.hex("#ADFF2F")(userId)}`);
  console.log(`${chalk.hex("#7FFF00")("ITEM")}   → ${chalk.hex("#ADFF2F")(item.name)}`);
  console.log(`${chalk.hex("#7FFF00")("SOURCE")} → ${chalk.hex("#ADFF2F")(sumber)}`);
  console.log(`${chalk.hex("#7FFF00")("LIMIT")}  → ${chalk.hex("#ADFF2F")(`${user.gachaToday}/${dailyLimit + user.extraLimit}`)}`);
  console.log(`${chalk.hex("#7FFF00")("BONUS")}  → ${chalk.hex("#ADFF2F")(user.bonus)}`);
  console.log(chalk.hex("#00FF00")("├──────────────────────────────────────────────┤"));
  console.log(chalk.hex("#00FF00")(`│ STATUS: ${chalk.bold.green("SUCCESS")} | CODE: ${chalk.white(code)} │`));
  console.log(chalk.hex("#00FF00")("└──────────────────────────────────────────────┘"));
});

// === /history ===
bot.onText(/\/history/, (msg) => {
  const user = loadData('users.json').find(u => u.id === msg.from.id);
  if (!user || !user.history.length) return safeSendMessage(msg.from.id, '📭 Belum ada riwayat gacha.');
  let text = '📝 Riwayat Gacha (10 Terbaru):\n';
  user.history.slice(-10).reverse().forEach((h, i) => { text += `${i + 1}. ${h.item} (${h.sumber}) — ${h.code}\n`; }); // 💡 TAMBAH SUMBER
  safeSendMessage(msg.from.id, text);
});

/// === /additem (otomatis nama file + auto broadcast) ===
bot.onText(/\/additem/, async (msg) => {
  const adminId = msg.from.id;
  if (!config.ADMIN_IDS.includes(adminId))
    return safeSendMessage(adminId, "❌ Kamu tidak punya izin untuk menambah item.");

  const reply = msg.reply_to_message;
  if (!reply)
    return safeSendMessage(adminId, "📎 *Reply* ke file, foto, video, teks, atau dokumen yang ingin dijadikan item.", { parse_mode: "Markdown" });

  const items = loadData("items.json");
  const users = loadData("users.json");

  try {
    let fileId, fileName, ext = ".bin", jenis = "📦 File", itemName;

    // === Deteksi tipe file ===
    if (reply.document) {
      fileId = reply.document.file_id;
      fileName = reply.document.file_name || "unknown.bin";
      ext = path.extname(fileName) || ".bin";
      itemName = path.basename(fileName, ext);
      jenis = "📄 Dokumen";
    } else if (reply.photo) {
      fileId = reply.photo.slice(-1)[0].file_id;
      fileName = `photo_${Date.now()}.jpg`;
      ext = ".jpg";
      itemName = path.basename(fileName, ext);
      jenis = "📸 Foto";
    } else if (reply.video) {
      fileId = reply.video.file_id;
      fileName = reply.video.file_name || `video_${Date.now()}.mp4`;
      ext = ".mp4";
      itemName = path.basename(fileName, ext);
      jenis = "🎥 Video";
    } else if (reply.audio) {
      fileId = reply.audio.file_id;
      fileName = reply.audio.file_name || `audio_${Date.now()}.mp3`;
      ext = ".mp3";
      itemName = path.basename(fileName, ext);
      jenis = "🎵 Audio";
    } else if (reply.voice) {
      fileId = reply.voice.file_id;
      fileName = `voice_${Date.now()}.ogg`;
      ext = ".ogg";
      itemName = path.basename(fileName, ext);
      jenis = "🎤 Voice";
    } else if (reply.text) {
      const itemName = reply.text.split("\n")[0].slice(0, 50).replace(/[^\w\s-]/g, "").trim() || `text_${Date.now()}`;
      const filePath = path.join(dataDir, `${itemName}.txt`);
      fs.writeFileSync(filePath, reply.text, "utf8");
      items.push({ name: itemName, filename: `${itemName}.txt` });
      saveData("items.json", items);
      await safeSendMessage(adminId, `✅ Item *${itemName}* (📝 Teks) berhasil ditambahkan.`, { parse_mode: "Markdown" });
      return broadcastNewItem(itemName, `${itemName}.txt`, users);
    } else {
      return safeSendMessage(adminId, "❌ Format tidak didukung. Gunakan *reply* ke dokumen, foto, video, teks, atau audio.", { parse_mode: "Markdown" });
    }

    // === Unduh file dari Telegram ===
    const fileInfo = await bot.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${config.BOT_TOKEN}/${fileInfo.file_path}`;
    const res = await fetch(fileUrl);
    if (!res.ok) throw new Error(`Gagal mengunduh file: ${res.statusText}`);
    const buffer = Buffer.from(await res.arrayBuffer());

    // === Simpan ke folder data ===
    const safeFile = `${itemName.replace(/\s+/g, "_")}${ext}`;
    const savePath = path.join(dataDir, safeFile);
    fs.writeFileSync(savePath, buffer);

    // === Simpan metadata item ===
    items.push({ name: itemName, filename: safeFile });
    saveData("items.json", items);

    // === Kirim notifikasi ke admin ===
    await safeSendMessage(
      adminId,
      `✅ *Item baru berhasil ditambahkan!*\n\n📦 Nama : *${itemName}*\n🗂 Jenis : ${jenis}\n📁 File : \`${safeFile}\`\n👥 Total user : ${users.length}`,
      { parse_mode: "Markdown" }
    );

    // === Kirim preview file ===
    try {
      if (ext.match(/\.(jpg|jpeg|png|gif)$/i))
        await bot.sendPhoto(adminId, savePath, { caption: `📸 Preview item: *${itemName}*`, parse_mode: "Markdown" });
      else if (ext.match(/\.(mp4|mov)$/i))
        await bot.sendVideo(adminId, savePath, { caption: `🎥 Preview item: *${itemName}*`, parse_mode: "Markdown" });
      else if (ext.match(/\.(mp3|ogg)$/i))
        await bot.sendAudio(adminId, savePath, { caption: `🎵 Preview item: *${itemName}*`, parse_mode: "Markdown" });
    } catch (e) {
      console.log("⚠️ Gagal kirim pratinjau:", e.message);
    }

    // === Broadcast otomatis ke semua user ===
    await broadcastNewItem(itemName, safeFile, users);

  } catch (err) {
    console.error("❌ Gagal add item:", err);
    safeSendMessage(adminId, `⚠️ *Gagal menambahkan item:*\n\`\`\`\n${err.message}\n\`\`\``, { parse_mode: "Markdown" });
  }
});

// === Fungsi broadcast item baru ===
async function broadcastNewItem(name, filename, users) {
  const notif = 
`🎁 *ITEM BARU TELAH HADIR!*
\`\`\`
Nama : ${name}
File : ${filename}
\`\`\`
✨ Coba peruntunganmu di /gacha sekarang!
`;

  let sent = 0;
  for (const u of users) {
    try {
      await bot.sendMessage(u.id || u.userId || u.chatId || u, notif, { parse_mode: "Markdown" });
      sent++;
    } catch (e) {
      console.log(`⚠️ Gagal kirim ke ${u.id || u}: ${e.message}`);
    }
    await new Promise(r => setTimeout(r, 250));
  }

  console.log(`✅ Broadcast item "${name}" terkirim ke ${sent}/${users.length} user.`);
}

// === /delitem ===
bot.onText(/\/delitem (.+)/, (msg, match) => {
  const userId = msg.from.id;
  if (!ADMIN_IDS.includes(userId)) return safeSendMessage(userId, "❌ Kamu tidak punya izin.");
  let items = loadData('items.json');
  const key = match[1].trim();

  // Mencari berdasarkan nama atau urutan (angka)
  const idx = isNaN(key) ? items.findIndex(i => i.name.toLowerCase() === key.toLowerCase()) : parseInt(key) - 1;

  if (idx < 0 || idx >= items.length) return safeSendMessage(userId, '❌ Item tidak ditemukan.');
  const removed = items.splice(idx, 1);

  // Hapus file fisik
  const filePath = path.join(dataDir, removed[0].filename);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
    console.log(chalk.yellow(`🗑 File item dihapus: ${removed[0].filename}`));
  }

  saveData('items.json', items);
  safeSendMessage(userId, `🗑 Item *${removed[0].name}* berhasil dihapus.`, { parse_mode: 'Markdown' });
});

bot.onText(/^\/listitem(@\w+)?$/, async (msg) => {
  try {
    const items = loadData('items.json');
    if (!Array.isArray(items) || !items.length)
      return bot.sendMessage(msg.chat.id, '📭 Tidak ada item.');

    const escapeHtml = (text) =>
      String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');

    let text = '<b>🎁 Daftar Item Gacha:</b>\n\n';
    items.forEach((i, n) => {
      text += `${n + 1}. ${escapeHtml(i.name)} — ${escapeHtml(i.filename)}\n`;
    });
    text += '\n💎 Bot Gacha Premium: <a href="https://t.me/JasherWafa_Bot">Klik di sini</a>';

    // Potong pesan panjang agar tidak melebihi limit Telegram
    const chunks = text.match(/[\s\S]{1,4000}/g) || [];
    for (const chunk of chunks) {
      await bot.sendMessage(msg.chat.id, chunk, {
        parse_mode: 'HTML',
        disable_web_page_preview: true
      });
    }

  } catch (err) {
    console.error(err);
    bot.sendMessage(msg.chat.id, '⚠️ Gagal memuat daftar item.');
  }
});

// === /clearitems ===
bot.onText(/\/clearitems/, async (msg) => {
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId))
    return safeSendMessage(adminId, "❌ Kamu tidak punya izin.");

  const items = loadData("items.json");

  if (!items.length) return safeSendMessage(adminId, "📭 Tidak ada item untuk dihapus.");

  for (const item of items) {
    const filePath = path.join(dataDir, item.filename);
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch (err) {
        console.error(`⚠️ Gagal hapus file ${item.filename}:`, err.message);
      }
    }
  }

  saveData("items.json", []);

  await safeSendMessage(adminId, "✅ Semua item berhasil dihapus.");
});

// === /leaderboard ===
bot.onText(/\/leaderboard/, async (msg) => {
  const chatId = msg.chat.id;
  const users = loadData('users.json');
  const refs = loadData('referrals.json');

  if (!users.length) return safeSendMessage(chatId, '📭 Belum ada data user.');

  const leaderboard = users.map(u => {
    const totalGacha = (u.history || []).length;
    const totalTeman = refs.filter(r => r.inviter == u.id).length;
    return { id: u.id, totalGacha, totalTeman };
  });

  leaderboard.sort((a, b) => b.totalGacha - a.totalGacha);

  const top10 = leaderboard.slice(0, 10);

  let text = '🏆 <b>TOP 10 GACHA</b>\n\n';
  for (const [i, u] of top10.entries()) {
    const user = users.find(x => x.id === u.id);
    const name = user && msg.chat.type === 'private' && msg.from.id === u.id // Tampilkan nama user sendiri di private chat
      ? (msg.from.first_name || 'Kamu')
      : (user && user.username
        ? `@${user.username}`
        : (user && user.first_name || `User${i + 1}`));
    text += `#${i + 1}. ${name}\n🎲 Gacha: ${u.totalGacha}x | 👥 Teman: ${u.totalTeman}\n\n`;
  }

  const totalUsers = users.length;
  text += `📊 Total pengguna: <b>${totalUsers}</b>`;

  await safeSendMessage(chatId, text, { parse_mode: 'HTML' });
});

// === /broadcast ===
bot.onText(/\/broadcast/, async (msg) => {
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId)) return safeSendMessage(adminId, "❌ Tidak punya izin.");
  const reply = msg.reply_to_message;
  if (!reply) return safeSendMessage(adminId, "📌 Reply pesan untuk broadcast.");

  const users = loadData("users.json");
  if (!users.length) return safeSendMessage(adminId, "📭 Belum ada user terdaftar.");

  const totalBlocks = 10;
  const blockFull = '▰';
  const blockEmpty = '▱';
  let success = 0;
  let failed = 0;

  let progressMsg = await safeSendMessage(adminId, `🚀 Broadcast ke ${users.length} pengguna...\n[${blockEmpty.repeat(totalBlocks)}] 0%\n✅ Sukses: 0 | ❌ Gagal: 0`);

  for (let i = 0; i < users.length; i++) {
    const u = users[i];
    try {
      if (reply.text) await safeSendMessage(u.id, reply.text);
      else if (reply.photo) await bot.sendPhoto(u.id, reply.photo.slice(-1)[0].file_id, { caption: reply.caption || "" });
      else if (reply.video) await bot.sendVideo(u.id, reply.video.file_id, { caption: reply.caption || "" });
      else if (reply.document) await bot.sendDocument(u.id, reply.document.file_id, { caption: reply.caption || "" });
      success++;
    } catch (e) { 
      failed++;
      console.log(`❌ Gagal kirim ke ${u.id}: ${e.message}`); 
    }

    const percent = Math.floor(((i + 1) / users.length) * 100);
    const blocks = Math.floor((percent / 100) * totalBlocks);
    const bar = blockFull.repeat(blocks) + blockEmpty.repeat(totalBlocks - blocks);

    if (progressMsg) {
      await bot.editMessageText(`🚀 Broadcast ke ${users.length} pengguna...\n[${bar}] ${percent}%\n✅ Sukses: ${success} | ❌ Gagal: ${failed}`, {
        chat_id: adminId,
        message_id: progressMsg.message_id
      }).catch(() => { }); // Ignore edit error
    }

    await new Promise(r => setTimeout(r, 30));
  }

  // hasil akhir
  if (progressMsg) {
    await bot.editMessageText(
      `🎯 Broadcast Selesai!\n────────────────────────\n📤 Total Pengguna: ${users.length}\n✅ Berhasil: ${success}\n❌ Gagal: ${failed}\n────────────────────────\n💎 Terima kasih telah menggunakan bot premium!`,
      { chat_id: adminId, message_id: progressMsg.message_id }
    ).catch(() => { });
  }
});

// === /backup (khusus file penting) ===
bot.onText(/\/backup/, async (msg) => {
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId))
    return safeSendMessage(adminId, "❌ Tidak punya izin.");

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupDir = path.join(process.cwd(), "backups");
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir);

  const backupFile = path.join(backupDir, `backup-data-${timestamp}.zip`);
  const progressMsg = await safeSendMessage(adminId, `📦 Membuat backup data penting...\n[▒▒▒▒▒▒▒▒▒▒] 0%`);

  const output = fs.createWriteStream(backupFile);
  const archive = archiver('zip', { zlib: { level: 9 } });

  archive.pipe(output);

  // 💡 TAMBAH codes.json
  const targetFiles = [
    "blacklist.json",
    "chats.json",
    "gacha_codes.json",
    "items.json",
    "referrals.json",
    "users.json",
    "codes.json"
  ];

  for (const file of targetFiles) {
    const filePath = path.join(dataDir, file);
    if (fs.existsSync(filePath)) archive.file(filePath, { name: file });
  }

  let progress = 0;
  const totalBlocks = 10;
  const interval = setInterval(async () => {
    progress++;
    const bar = '█'.repeat(progress) + '▒'.repeat(totalBlocks - progress);
    const percent = progress * 10;
    try {
      await bot.editMessageText(`📦 Membuat backup data penting...\n[${bar}] ${percent}%`, {
        chat_id: adminId,
        message_id: progressMsg.message_id
      }).catch(() => {});
    } catch {}
    if (progress >= totalBlocks) clearInterval(interval);
  }, 300);

  await archive.finalize();

  output.on("close", async () => {
    clearInterval(interval);
    const sizeMB = (archive.pointer() / 1024 / 1024).toFixed(2);
    await bot.editMessageText(`✅ Backup selesai!\n📁 File: ${backupFile}\n📦 Ukuran: ${sizeMB} MB`, {
      chat_id: adminId,
      message_id: progressMsg.message_id
    }).catch(() => {});

    if (sizeMB <= 50) {
      await bot.sendDocument(adminId, backupFile, {
        caption: `📦 Backup data penting - ${timestamp}`
      }).catch(e => console.error("Gagal kirim backup:", e.message));
    } else {
      await safeSendMessage(adminId, `⚠️ File backup terlalu besar (${sizeMB} MB). Ambil langsung dari server.`);
    }
  });
});


// === Fungsi Backup Otomatis (khusus file penting) ===
const autoBackupDir = path.join(process.cwd(), "autobackups");
if (!fs.existsSync(autoBackupDir)) fs.mkdirSync(autoBackupDir);

async function autoBackup() {
  const backupFile = path.join(autoBackupDir, `backup-${Date.now()}.zip`);
  // 💡 TAMBAH codes.json
  const targetFiles = [
    "blacklist.json",
    "chats.json",
    "gacha_codes.json",
    "items.json",
    "referrals.json",
    "users.json",
    "codes.json"
  ];

  try {
    await new Promise((resolve, reject) => {
      const output = fs.createWriteStream(backupFile);
      const archive = archiver('zip', { zlib: { level: 9 } });
      output.on("close", resolve);
      archive.on("error", reject);
      archive.pipe(output);

      for (const file of targetFiles) {
        const filePath = path.join(dataDir, file);
        if (fs.existsSync(filePath)) archive.file(filePath, { name: file });
      }

      archive.finalize();
    });

    console.log(chalk.green(`✅ Backup otomatis selesai: ${backupFile}`));

    for (const adminId of ADMIN_IDS) {
      await safeSendMessage(adminId, `📦 Notifikasi: Backup otomatis selesai! (${new Date().toLocaleTimeString()})`);
    }

    // Hapus backup lama (>3 hari)
    const files = await fs.readdir(autoBackupDir);
    const now = Date.now();
    for (const file of files) {
      const filePath = path.join(autoBackupDir, file);
      const stats = await fs.stat(filePath);
      if (now - stats.mtimeMs > 3 * 24 * 60 * 60 * 1000) {
        await fs.remove(filePath);
        console.log(chalk.yellow(`🧹 Backup lama dihapus: ${file}`));
      }
    }
  } catch (err) {
    console.error(chalk.red("❌ Backup otomatis gagal:"), err);
  }
}

// === Jadwal Auto Backup Setiap 3 Jam ===
schedule.scheduleJob("0 */3 * * *", () => {
  console.log(chalk.blue("🕓 Menjalankan backup otomatis 3 jam..."));
  autoBackup();
});

// === Penanganan Bot Masuk/Keluar Grup ===
bot.on('my_chat_member', async (msg) => {
  try {
    const chatId = msg.chat.id;

    if (!['group', 'supergroup'].includes(msg.chat.type)) return;

    const oldStatus = msg.old_chat_member?.status;
    const newStatus = msg.new_chat_member?.status;
    const chatTitle = msg.chat.title || 'Grup ini';
    const userId = msg.from?.id;
    const username = msg.from?.username || msg.from?.first_name || 'Unknown';

    let chats = loadData('chats.json');
    let users = loadData('users.json');

    // === 1️⃣ BOT DIKELUARKAN DARI GRUP ===
    if (oldStatus === 'member' && newStatus === 'kicked') {
      const groupIndex = chats.findIndex(c => c.id === chatId);
      if (groupIndex !== -1) {
        chats.splice(groupIndex, 1);
        saveData('chats.json', chats);
      }

      if (userId) {
        let user = users.find(u => u.id === userId);
        if (user && user.bonus > 0) {
          user.bonus = Math.max(0, user.bonus - 2);
          saveData('users.json', users);
          await safeSendMessage(
            userId,
            `⚠️ *BOT TELAH DIKELUARKAN DARI GRUP*\n\n` +
            `📛 Grup: *${chatTitle}*\n` +
            `💎 Bonus *2x Gacha* kamu telah *dicabut* karena bot dikeluarkan.\n\n` +
            `💡 Undang kembali bot ke grup aktif untuk mendapatkan bonus lagi.`,
            { parse_mode: 'Markdown' }
          );
        }
      }

      const userTag = username.startsWith('@') ? username : `@${username}`;
      const msgAdmin =
        `🚫 *BOT DIKELUARKAN DARI GRUP*\n\n` +
        `📛 *Nama Grup:* ${chatTitle}\n` +
        `🆔 *ID Grup:* \`${chatId}\`\n\n` +
        `👤 *Dikeluarkan oleh:* ${userTag}\n` +
        `🆔 *ID User:* \`${userId}\`\n\n` +
        `🎁 *Bonus Dicabut:* -2x Gacha`;

      for (const adminId of ADMIN_IDS) {
        await safeSendMessage(adminId, msgAdmin, { parse_mode: 'Markdown' });
      }

      console.log(chalk.red(`🚪 Bot dikeluarkan dari ${chatTitle}, bonus user dicabut.`));
      return;
    }

    // === 2️⃣ BOT DITAMBAHKAN KE GRUP ===
    if (newStatus !== 'member') return;

    let addingUserId = msg.from?.id;

    if (!addingUserId) {
      const admins = await bot.getChatAdministrators(chatId);
      const firstAdmin = admins.find(a => !a.user.is_bot);
      if (firstAdmin) {
        addingUserId = firstAdmin.user.id;
      }
    }

    if (!addingUserId) return;

    let memberCount = 0;
    try {
      memberCount = await bot.getChatMemberCount(chatId);
    } catch { }

    if (memberCount < 20) {
      await safeSendMessage(
        chatId,
        `🚫 *BOT GACHA PREMIUM* tidak dapat diaktifkan di grup ini.\n\n` +
        `👥 Jumlah member saat ini: *${memberCount}*\n` +
        `📈 Minimal member yang dibutuhkan: *20*\n\n` +
        `💡 Tambahkan lebih banyak anggota, lalu undang bot kembali.`,
        { parse_mode: 'Markdown' }
      );

      await safeSendMessage(
        addingUserId,
        `⚠️ *${chatTitle}* belum memenuhi syarat minimal 20 member.\n\n` +
        `⏳ Bot akan keluar otomatis dalam *5 detik*...`,
        { parse_mode: 'Markdown' }
      );

      setTimeout(async () => {
        try {
          await bot.leaveChat(chatId);
          console.log(`🚪 Bot keluar dari ${chatTitle} karena member kurang dari 20.`);
        } catch (err) {
          console.error(`Gagal keluar dari grup:`, err.message);
        }
      }, 5000);

      return;
    }

    // --- Beri Bonus ---
    let group = chats.find(c => c.id === chatId);
    if (!group) {
      group = { id: chatId, name: chatTitle, bonusGiven: false };
      chats.push(group);
    }

    if (group.bonusGiven) {
      console.log(`ℹ️ Grup ${chatId} sudah pernah dapat bonus, dilewati.`);
      return;
    }

    group.bonusGiven = true;
    saveData('chats.json', chats);

    const today = new Date().toDateString();
    let user = users.find(u => u.id === addingUserId);

    if (!user) {
      // 💡 TAMBAH redeemedCodes
      user = { id: addingUserId, gachaToday: 0, bonus: 2, extraLimit: 0, history: [], lastDate: today, redeemedCodes: [] };
      users.push(user);
    } else {
      user.bonus = (Number(user.bonus) || 0) + 2;
    }
    // 💡 INIT redeemedCodes jika belum ada
    if (!Array.isArray(user.redeemedCodes)) user.redeemedCodes = [];
    saveData('users.json', users);

    await safeSendMessage(
      addingUserId,
      `\`\`\`\n` +
      `╭──────────────────────────────╮\n` +
      `│        ✨ BONUS GACHA ✨       │\n` +
      `├──────────────────────────────┤\n` +
      `🎉 Terima kasih telah menambahkan\n` +
      `BOT GACHA PREMIUM ke grup *${chatTitle}*!\n\n` +
      `🎁 Kamu mendapatkan: *2x Bonus Gacha*\n` +
      `🪄 Bonus ini bisa langsung digunakan saat /gacha!\n` +
      `╰──────────────────────────────╯\n` +
      `\`\`\``,
      { parse_mode: 'Markdown' }
    );

    const userTag = username.startsWith('@') ? username : `@${username}`;
    const detailMessage =
      `💎 *BOT DITAMBAHKAN KE GRUP BARU*\n\n` +
      `📛 *Nama Grup:* ${chatTitle}\n` +
      `🆔 *ID Grup:* \`${chatId}\`\n` +
      `👥 *Jumlah Member:* ${memberCount}\n\n` +
      `👤 *User Penambah:* ${userTag}\n` +
      `🆔 *ID User:* \`${addingUserId}\`\n\n` +
      `🎁 *Bonus Diberikan:* 2x Gacha\n` +
      `🏆 *Status:* ✅ Berhasil`;

    for (const adminId of ADMIN_IDS) {
      await safeSendMessage(adminId, detailMessage, { parse_mode: 'Markdown' });
    }

    console.log(chalk.green(`✅ Bot ditambahkan ke ${chatTitle}, bonus 2x gacha diberikan ke ${username}`));

  } catch (err) {
    console.error(chalk.red('❌ Error handle my_chat_member:'), err.message);
  }
});

// === Admin Lihat Info Grup (/infogrub) ===
bot.onText(/\/infogrub/, async (msg) => {
  const userId = msg.from.id;
  if (!ADMIN_IDS.includes(userId)) return safeSendMessage(userId, "❌ Tidak punya izin.");

  const chats = loadData('chats.json');
  if (chats.length === 0) return safeSendMessage(userId, "❌ Bot belum ada di grup manapun.");

  let text = "📋 Daftar Grup Bot:\n\n";

  for (const group of chats) {
    try {
      const chat = await bot.getChat(group.id);
      text += `• ${chat.title || 'Unknown'} (ID: ${group.id})\n`;
    } catch {
      text += `• ID: ${group.id} (gagal ambil info, mungkin bot sudah dikeluarkan)\n`;
    }
  }

  safeSendMessage(userId, text);
});

// === Broadcast Pesan ke Grup (/bcgrub) ===
bot.onText(/\/bcgrub/, async (msg) => {
  const userId = msg.from.id;
  if (!ADMIN_IDS.includes(userId))
    return safeSendMessage(userId, "❌ *Kamu bukan admin, tidak bisa broadcast ke grup.*", { parse_mode: "Markdown" });

  if (!msg.reply_to_message)
    return safeSendMessage(userId, "⚠️ *Reply pesan yang ingin di-broadcast ke grup.*", { parse_mode: "Markdown" });

  const chats = loadData('chats.json');
  if (!chats || chats.length === 0)
    return safeSendMessage(userId, "❌ *Bot belum ada di grup manapun.*", { parse_mode: "Markdown" });

  const total = chats.length;
  let sukses = 0;
  let gagal = 0;

  let progressMsg = await safeSendMessage(
    userId,
    "📡 *Mengirim broadcast ke grup...*\n[▒▒▒▒▒▒▒▒▒▒] 0%",
    { parse_mode: "Markdown" }
  );

  const updateBar = async (sent) => {
    if (!progressMsg || !progressMsg.chat) return;
    const percent = Math.floor((sent / total) * 100);
    const filled = Math.round(percent / 10);
    const bar = "█".repeat(filled) + "▒".repeat(10 - filled);

    try {
      await bot.editMessageText(
        `📡 *Sedang broadcast ke grup...*\n[${bar}] ${percent}%`,
        {
          chat_id: progressMsg.chat.id,
          message_id: progressMsg.message_id,
          parse_mode: "Markdown",
        }
      ).catch(() => { });
    } catch (err) {
      // ignore
    }
  };

  for (let i = 0; i < total; i++) {
    const chat = chats[i];
    try {
      await bot.forwardMessage(
        chat.id,
        msg.reply_to_message.chat.id,
        msg.reply_to_message.message_id
      );
      sukses++;
    } catch (err) {
      console.log(chalk.yellow(`⚠️ Gagal kirim ke grup ${chat.id}: ${err.message}`));
      gagal++;
    }

    await updateBar(i + 1);
    await new Promise((r) => setTimeout(r, 300));
  }

  const resultText = `
\`\`\`  
✨ *Broadcast Selesai!*
────────────────────
📊 *Statistik:*
> Total Grup: ${total}  
> ✅ Berhasil: ${sukses}  
> ❌ Gagal: ${gagal}  
────────────────────
🔥 *Broadcast sukses dikirim!*
\`\`\`
`;

  if (progressMsg && progressMsg.chat) {
    try {
      await bot.editMessageText(resultText, {
        chat_id: progressMsg.chat.id,
        message_id: progressMsg.message_id,
        parse_mode: "Markdown",
      });
    } catch (err) {
      safeSendMessage(userId, resultText, { parse_mode: "Markdown" });
    }
  } else {
    safeSendMessage(userId, resultText, { parse_mode: "Markdown" });
  }
});

// === /addlimit <user_id> <jumlah> ===
bot.onText(/\/addlimit (\d+) (\d+)/, async (msg, match) => {
  if (!msg || !msg.chat) return;
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId)) return safeSendMessage(adminId, "❌ Tidak punya izin.");

  const targetId = Number(match[1]);
  const jumlah = Number(match[2]);
  if (!targetId || isNaN(jumlah) || jumlah <= 0) {
    return safeSendMessage(adminId, "⚠️ Format salah.\nGunakan: /addlimit <user_id> <jumlah>");
  }

  let users = loadData('users.json');
  let user = users.find(u => Number(u.id) === targetId);

  if (!user) {
    // 💡 TAMBAH redeemedCodes
    user = { id: targetId, gachaToday: 0, bonus: 0, extraLimit: 0, history: [], lastDate: new Date().toDateString(), redeemedCodes: [] };
    users.push(user);
  }
  // 💡 INIT redeemedCodes jika belum ada
  if (!Array.isArray(user.redeemedCodes)) user.redeemedCodes = [];


  const waitMsg = await safeSendMessage(adminId, "🕓 Memproses permintaan...");

  user.bonus = (Number(user.bonus) || 0) + jumlah;
  saveData('users.json', users);

  const time = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

  if (waitMsg) {
    await bot.editMessageText(
      `✅ *Bonus Gacha Ditambahkan*\n\n` +
      `👤 User ID: \`${targetId}\`\n` +
      `🎟️ Ditambah: +${jumlah}\n` +
      `💰 Total Bonus: ${user.bonus}\n\n` +
      `🕒 ${time}`,
      {
        chat_id: waitMsg.chat.id,
        message_id: waitMsg.message_id,
        parse_mode: "Markdown"
      }
    ).catch(() => { });
  }

  safeSendMessage(
    targetId,
    `🎁 *Bonus Diterima*\n\n` +
    `Kamu mendapatkan +${jumlah} tiket gacha.\n` +
    `Total tiketmu sekarang: *${user.bonus}* 🎟️`,
    { parse_mode: "Markdown" }
  );
});


// === /hapuslimit <user_id> ===
bot.onText(/\/hapuslimit (\d+)/, async (msg, match) => {
  if (!msg || !msg.chat) return;
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId)) return safeSendMessage(adminId, "❌ Tidak punya izin.");

  const targetId = Number(match[1]);
  if (!targetId) {
    return safeSendMessage(adminId, "⚠️ Format salah.\nGunakan: /hapuslimit <user_id>");
  }

  let users = loadData('users.json');
  let userIndex = users.findIndex(u => Number(u.id) === targetId);

  const waitMsg = await safeSendMessage(adminId, "🕓 Menghapus data user...");

  if (userIndex === -1) {
    return bot.editMessageText(`❌ User ${targetId} tidak ditemukan.`, {
      chat_id: waitMsg.chat.id,
      message_id: waitMsg.message_id
    }).catch(() => { });
  }

  users[userIndex].gachaToday = 0;
  users[userIndex].bonus = 0;
  users[userIndex].extraLimit = 0;
  users[userIndex].lastDate = new Date().toDateString();

  saveData('users.json', users);
  const time = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

  if (waitMsg) {
    await bot.editMessageText(
      `✅ *Limit Direset*\n\n` +
      `👤 User ID: \`${targetId}\`\n` +
      `🎯 Limit & bonus telah dihapus.\n\n` +
      `🕒 ${time}`,
      {
        chat_id: waitMsg.chat.id,
        message_id: waitMsg.message_id,
        parse_mode: "Markdown"
      }
    ).catch(() => { });
  }

  safeSendMessage(
    targetId,
    `🔁 *Limit Direset*\n\n` +
    `Limit dan bonus kamu telah direset oleh admin.\n` +
    `Kamu bisa mulai gacha lagi sekarang.`,
    { parse_mode: "Markdown" }
  );
});


// === /addlimitall <jumlah> ===
bot.onText(/\/addlimitall (\d+)/, async (msg, match) => {
  if (!msg || !msg.chat) return;
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId)) return safeSendMessage(adminId, "❌ Tidak punya izin.");

  const jumlah = Number(match[1]);
  if (!jumlah || jumlah <= 0) {
    return safeSendMessage(adminId, "⚠️ Format salah.\nGunakan: /addlimitall <jumlah>");
  }

  const users = loadData('users.json');
  if (!users.length) return safeSendMessage(adminId, "📭 Tidak ada user di data.");

  const waitMsg = await safeSendMessage(adminId, `🕓 Menambahkan +${jumlah} limit ke semua user...`);

  users.forEach(u => {
    u.bonus = (Number(u.bonus) || 0) + jumlah;
    // 💡 INIT redeemedCodes jika belum ada
    if (!Array.isArray(u.redeemedCodes)) u.redeemedCodes = [];
  });
  saveData('users.json', users);

  const time = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
  if (waitMsg) {
    await bot.editMessageText(
      `✅ *Bonus Massal Ditambahkan*\n\n` +
      `🎟️ Semua user mendapatkan +${jumlah} tiket gacha!\n` +
      `👥 Total user: ${users.length}\n\n` +
      `🕒 ${time}`,
      {
        chat_id: waitMsg.chat.id,
        message_id: waitMsg.message_id,
        parse_mode: "Markdown"
      }
    ).catch(() => { });
  }

  // Broadcast ke semua user (gunakan safeSendMessage)
  for (const u of users) {
    safeSendMessage(
      u.id,
      `🎉 *Bonus Massal!*\n\nAdmin memberikan +${jumlah} tiket gacha untuk semua pemain!\n` +
      `Cek saldo tiketmu sekarang: *${u.bonus}* 🎟️`,
      { parse_mode: "Markdown" }
    );
  }
});

// === CEK STATUS USER (KHUSUS ADMIN) ===
bot.onText(/\/checkstat (\d+)/, async (msg, match) => {
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId))
    return safeSendMessage(adminId, "❌ Kamu tidak punya izin untuk perintah ini.");

  const targetId = Number(match[1]);
  const users = loadData('users.json');
  const refs = loadData('referrals.json');
  const today = new Date().toDateString();

  const user = users.find(u => u.id === targetId);
  if (!user) return safeSendMessage(adminId, "⚠️ User tidak ditemukan di database.");

  const totalLimit = config.GACHA_LIMIT || 5;
  const usedLimit = user.gachaToday || 0;
  const remainingLimit = Math.max(totalLimit - usedLimit, 0);
  const bonus = user.bonus || 0;
  const extraLimit = user.extraLimit || 0; // 💡 TAMBAH extraLimit

  const invitedAll = refs.filter(r => r.inviter === targetId).length;
  const invitedToday = refs.filter(r =>
    r.inviter === targetId && new Date(r.date).toDateString() === today
  ).length;

  const text = `
\`\`\`
📊 CEK DATA USER
──────────────────────
👤 USER ID: ${targetId}
📅 Hari ini: ${today}
🎰 Sudah gacha: ${usedLimit}x
⏳ Sisa limit harian: ${remainingLimit}
⚡ Extra limit (Redeem): ${extraLimit} 💡
🎟 Bonus gacha: ${bonus}
👥 Undangan hari ini: ${invitedToday}
👑 Total teman diundang: ${invitedAll}
──────────────────────
Gunakan data ini untuk memantau aktivitas user.
\`\`\`
`;

  await safeSendMessage(adminId, text, { parse_mode: "Markdown" });
});

// === CEK STATUS USER (MYSTAT) ===
bot.onText(/\/mystat/, async (msg) => {
  const userId = msg.from.id;
  const users = loadData('users.json');
  const refs = loadData('referrals.json');
  const today = new Date().toDateString();

  let user = users.find(u => u.id === userId);
  if (!user) {
    return safeSendMessage(userId, "⚠️ Kamu belum pernah gacha, ketik /start dulu.");
  }

  // Hitung data
  const totalLimit = config.GACHA_LIMIT || 5;
  const usedLimit = user.gachaToday || 0;
  const remainingLimit = Math.max(totalLimit - usedLimit, 0);
  const bonus = user.bonus || 0;
  const extraLimit = user.extraLimit || 0; // 💡 TAMBAH extraLimit

  // Hitung jumlah undangan
  const invitedAll = refs.filter(r => r.inviter === userId).length;
  const invitedToday = refs.filter(r =>
    r.inviter === userId && new Date(r.date).toDateString() === today
  ).length;

  const text = `
\`\`\`
📊 STATUS KAMU
──────────────────────
📅 Hari ini: ${today}
🎰 Sudah gacha: ${usedLimit}x
⏳ Sisa limit harian: ${remainingLimit}
⚡ Extra limit (Redeem): ${extraLimit} 💡
🎟 Bonus gacha: ${bonus}
👥 Undangan hari ini: ${invitedToday}
👑 Total teman diundang: ${invitedAll}
──────────────────────
Gunakan bonusmu untuk gacha lebih banyak! 🎁
\`\`\`
`;

  await safeSendMessage(userId, text, { parse_mode: "Markdown" });
});

// === Blacklist: Add ===
bot.onText(/\/blacklist (\d+)/, async (msg, match) => {
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId)) return safeSendMessage(adminId, "❌ Kamu bukan admin.");

  const targetId = Number(match[1]);
  let list = loadData('blacklist.json');

  if (list.includes(targetId)) return safeSendMessage(adminId, `⚠️ ID \`${targetId}\` sudah di-blacklist.`, { parse_mode: 'Markdown' });

  list.push(targetId);
  saveData('blacklist.json', list);
  await safeSendMessage(adminId, `🚫 ID \`${targetId}\` ditambahkan ke blacklist.`, { parse_mode: 'Markdown' });
});

// === Blacklist: Delete ===
bot.onText(/\/delblacklist (\d+)/, async (msg, match) => {
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId)) return safeSendMessage(adminId, "❌ Kamu bukan admin.");

  const targetId = Number(match[1]);
  let list = loadData('blacklist.json');

  if (!list.includes(targetId)) return safeSendMessage(adminId, `⚠️ ID \`${targetId}\` tidak ada di blacklist.`, { parse_mode: 'Markdown' });

  list = list.filter(id => id !== targetId);
  saveData('blacklist.json', list);
  await safeSendMessage(adminId, `🗑️ ID \`${targetId}\` telah dihapus dari blacklist.`, { parse_mode: 'Markdown' });
});

// === Blacklist: List ===
bot.onText(/\/listblacklist/, async (msg) => {
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId)) return safeSendMessage(adminId, "❌ Kamu bukan admin.");

  const list = loadData('blacklist.json');
  if (!list.length) return safeSendMessage(adminId, "✅ Tidak ada user yang di-blacklist.");

  const lines = list.map((id, i) => `${i + 1}. \`${id}\``).join("\n");
  await safeSendMessage(adminId, `🚫 *Blacklist Saat Ini:*\n\n${lines}`, { parse_mode: 'Markdown' });
});

// === /listadmin (Dipertahankan di memori/config) ===
bot.onText(/\/listadmin/, async (msg) => {
  const userId = msg.from.id;
  if (!ADMIN_IDS.includes(userId))
    return safeSendMessage(userId, "❌ Hanya admin yang bisa melihat daftar admin.");

  if (!ADMIN_IDS.length)
    return safeSendMessage(userId, "📭 Belum ada admin yang terdaftar.");

  let text = "👑 <b>Daftar Admin Aktif (dari config.js):</b>\n";
  for (const id of ADMIN_IDS) {
    text += `• <code>${id}</code>\n`;
  }

  await safeSendMessage(userId, text, { parse_mode: "HTML" });
});

// === /cekid ===
bot.onText(/\/cekid/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  try {
    const userProfilePhotos = await bot.getUserProfilePhotos(userId, { limit: 1 }).catch(() => null);
    const username = msg.from.username || "-";
    const firstName = msg.from.first_name || "-";
    const lastName = msg.from.last_name || "-";
    const fullName = `${firstName} ${lastName}`.trim();

    let photoFileId = null;
    if (userProfilePhotos && userProfilePhotos.total_count > 0) {
      photoFileId = userProfilePhotos.photos[0][0].file_id;
    }

    const text = `
📝 *INFO DETAIL KAMU*
────────────────────────
👤 Nama: ${fullName}
🆔 ID: \`${userId}\`  
💻 Username: @${username}
────────────────────────
`;

    const replyMarkup = {
      inline_keyboard: [
        [{ text: "𝐁𝐨𝐭 𝐆𝐚𝐜𝐡𝐚 𝐏𝐫𝐞𝐦𝐢𝐮𝐦", url: "https://t.me/BotGachaGudelBot" }]
      ]
    };

    if (photoFileId) {
      await bot.sendPhoto(chatId, photoFileId, { caption: text, parse_mode: "Markdown", reply_markup: replyMarkup });
    } else {
      await safeSendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: replyMarkup });
    }

  } catch (e) {
    await safeSendMessage(chatId, `❌ Terjadi kesalahan saat cek ID: ${e.message}`);
  }
});

// === /ping ===
bot.onText(/\/ping(@\w+)?/, async (msg) => {
  const chatId = msg.chat.id;

  try {
    const start = Date.now();
    const pingMsg = await safeSendMessage(chatId, "🏓 *Mengecek status server...*", { parse_mode: "Markdown" });
    if (!pingMsg) return;

    const latency = Date.now() - start;

    let cpuLoad = 0;
    try {
      const cpu = await si.currentLoad();
      cpuLoad = cpu.currentLoad;
    } catch { }

    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const uptime = os.uptime();
    const uptimeH = Math.floor(uptime / 3600);
    const uptimeM = Math.floor((uptime % 3600) / 60);

    let status = "";
    if (latency < 100) status = "⚡ *Super Cepat* — server stabil tanpa delay!";
    else if (latency < 300) status = "🚀 *Cukup Cepat* — performa normal.";
    else if (latency < 600) status = "⚠️ *Sedikit Delay* — koneksi agak lambat.";
    else status = "🐢 *Lambat* — mungkin panel/server sedang berat.";

    const text = `
\`\`\`
🏓  Ping Server Bot
────────────────────────
📡  Latency : ${latency} ms
💻  CPU Usage : ${cpuLoad.toFixed(1)}%
🧠  RAM Used : ${(usedMem / 1024 / 1024).toFixed(1)} MB
🗄️  Total RAM : ${(totalMem / 1024 / 1024).toFixed(0)} MB
⏳  Uptime : ${uptimeH} jam ${uptimeM} menit
────────────────────────
${status}
\`\`\`
`;

    await bot.editMessageText(text, {
      chat_id: chatId,
      message_id: pingMsg.message_id,
      parse_mode: "Markdown"
    });

  } catch (err) {
    console.error(chalk.red("❌ Error /ping:"), err.message);
    try { await safeSendMessage(chatId, "⚠️ Gagal mengecek ping bot."); } catch { }
  }
});

// === /cekhistory ===
bot.onText(/\/cekhistory (\d+)/, async (msg, match) => {
  const userIdAdmin = msg.from.id;

  if (!ADMIN_IDS.includes(userIdAdmin)) {
    return safeSendMessage(userIdAdmin, "🚫 Hanya admin yang bisa menggunakan perintah ini.");
  }

  const userIdTarget = Number(match[1]);
  const users = loadData('users.json');
  const user = users.find(u => u.id === userIdTarget);

  if (!user) return safeSendMessage(userIdAdmin, `❌ User dengan ID ${userIdTarget} tidak ditemukan.`);

  const today = new Date();
  const todayHistory = (user.history || []).filter(h => {
    const hDate = new Date(h.date);
    return hDate.getFullYear() === today.getFullYear() &&
      hDate.getMonth() === today.getMonth() &&
      hDate.getDate() === today.getDate();
  });

  if (!todayHistory.length) {
    return safeSendMessage(userIdAdmin, `ℹ️ User dengan ID ${userIdTarget} belum melakukan gacha hari ini.`);
  }

  const gachaCount = todayHistory.length;
  const itemsList = todayHistory
    .map((h, i) => `${i + 1}. ${h.item} (${h.sumber || 'Limit'}) — ${new Date(h.date).toLocaleTimeString("id-ID")}`)
    .join('\n');

  const message = `
🎰 *History Gacha Hari Ini*
────────────────────────
👤 User ID: ${userIdTarget}
📅 Tanggal: ${today.toLocaleDateString("id-ID")}
🪄 Total Gacha: ${gachaCount} kali

📦 Item yang didapat:
${itemsList}
────────────────────────`;

  await safeSendMessage(userIdAdmin, message, { parse_mode: "Markdown" });
});

// === /createcode <limit> ===
bot.onText(/\/createcode (\d+)/, async (msg, match) => {
  const adminId = msg.from.id;
  if (!ADMIN_IDS.includes(adminId))
    return safeSendMessage(adminId, "❌ Kamu tidak punya izin.");

  const limit = Number(match[1]);
  if (isNaN(limit) || limit <= 0)
    return safeSendMessage(adminId, "⚠️ Format salah.\nGunakan: /createcode <jumlah_limit>");

  const code = nanoid(8).toUpperCase();
  let codes = loadData('codes.json');

  const createdAt = new Date();
  const expiresAt = new Date(createdAt.getTime() + 24 * 60 * 60 * 1000); // 24 jam

  codes.push({
    code,
    limit,
    used: false,
    usedBy: null,
    createdAt,
    expiresAt,
    expired: false
  });

  saveData('codes.json', codes);

  // 🔔 Kirim ke admin
  await safeSendMessage(
    adminId,
    `✅ *Kode Redeem Berhasil Dibuat!*\n\n🎟️ Code: \`${code}\`\n💎 Limit Tambahan: +${limit}\n🕒 Berlaku hingga: ${expiresAt.toLocaleString("id-ID")}\n\nGunakan dengan perintah:\n/redeem ${code}`,
    { parse_mode: "Markdown" }
  );

  // 📢 Kirim ke Channel
  if (config.CHANNEL_ID) {
    const channelId = config.CHANNEL_ID.startsWith("@")
      ? config.CHANNEL_ID
      : `@${config.CHANNEL_ID}`;

    const channelMsg = `
🎁 *Kode Redeem Baru Tersedia!*
━━━━━━━━━━━━━━━━━━━━━━
🎟️ Kode: \`${code}\`
💎 Bonus: +${limit} Extra Gacha
⏰ Berlaku: 24 Jam Sejak Diumumkan
━━━━━━━━━━━━━━━━━━━━━━
Gunakan perintah:
/redeem ${code}
Untuk menukarkan hadiahnya 🎉
`;

    await safeSendMessage(channelId, channelMsg, { parse_mode: "Markdown" })
      .catch(err => console.error("Gagal kirim ke channel:", err.message));
  }
});


// === /redeem <code> ===
bot.onText(/\/redeem (.+)/, async (msg, match) => {
  const userId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : msg.from.first_name || "Pengguna";
  const inputCode = match[1].trim().toUpperCase();

  let users = loadData('users.json');
  let codes = loadData('codes.json');

  let user = users.find(u => u.id === userId);
  if (!user) {
    user = { id: userId, gachaToday: 0, bonus: 0, extraLimit: 0, history: [], lastDate: new Date().toDateString(), redeemedCodes: [] };
    users.push(user);
  }
  if (!Array.isArray(user.redeemedCodes)) user.redeemedCodes = [];

  const found = codes.find(c => c.code === inputCode);

  if (!found) {
    return safeSendMessage(userId, "❌ Kode tidak ditemukan atau tidak valid.");
  }

  const now = new Date();
  if (found.expired || now > new Date(found.expiresAt)) {
    found.expired = true;
    saveData('codes.json', codes);
    return safeSendMessage(userId, "⏰ Kode ini sudah kedaluwarsa dan tidak bisa digunakan lagi.");
  }

  if (found.used) {
    return safeSendMessage(userId, "⚠️ Kode ini sudah digunakan oleh orang lain dan sudah tidak berlaku.");
  }

  if (user.redeemedCodes.includes(inputCode)) {
    return safeSendMessage(userId, "⚠️ Kamu sudah pernah menukarkan kode ini sebelumnya.");
  }

  // Tandai kode sebagai digunakan
  found.used = true;
  found.usedBy = userId;
  found.redeemedAt = now;

  user.extraLimit = (user.extraLimit || 0) + found.limit;
  user.redeemedCodes.push(inputCode);

  saveData('codes.json', codes);
  saveData('users.json', users);

  // ✅ Kirim ke user
  await safeSendMessage(
    userId,
    `🎉 *Kode Berhasil Ditukarkan!*\n\n✅ Kamu mendapatkan tambahan *${found.limit} Extra Limit Gacha!*\n🪄 Sekarang total Extra Limit kamu: ${user.extraLimit}\n\nGunakan di /gacha sekarang!`,
    { parse_mode: "Markdown" }
  );

  // 📢 Kirim ke Channel jika tersedia
  if (config.CHANNEL_ID) {
    const channelId = config.CHANNEL_ID.startsWith("@")
      ? config.CHANNEL_ID
      : `@${config.CHANNEL_ID}`;

    const channelMsg = `
💥 *Kode Redeem Digunakan!*
━━━━━━━━━━━━━━━━━━━━━━
🎟️ Kode: \`${inputCode}\`
👤 Pengguna: ${username}
💎 Bonus: +${found.limit} Extra Gacha
🕒 Waktu: ${now.toLocaleString("id-ID")}
━━━━━━━━━━━━━━━━━━━━━━
Kode ini sekarang *tidak bisa digunakan lagi*.
`;

    await safeSendMessage(channelId, channelMsg, { parse_mode: "Markdown" })
      .catch(err => console.error("Gagal kirim ke channel:", err.message));
  }
});


// === AUTO EXPIRE CHECK (tiap 1 jam) ===
schedule.scheduleJob("0 * * * *", async () => {
  let codes = loadData('codes.json');
  const now = new Date();
  let expiredNow = [];

  for (const code of codes) {
    if (!code.used && !code.expired && new Date(code.expiresAt) < now) {
      code.expired = true;
      expiredNow.push(code.code);
    }
  }

  if (expiredNow.length > 0) {
    saveData('codes.json', codes);

    for (const adminId of ADMIN_IDS) {
      await safeSendMessage(
        adminId,
        `⏰ *Kode Redeem Kadaluarsa Otomatis:*\n\n${expiredNow.map(c => `- ${c}`).join("\n")}\n\n🕒 Semua kode di atas sudah lebih dari 24 jam dan dinonaktifkan.`,
        { parse_mode: "Markdown" }
      );
    }

    console.log(`🕒 ${expiredNow.length} kode kadaluarsa otomatis (${new Date().toLocaleString("id-ID")})`);
  }
});

// ------------------------------------------------------------------
//                             ERROR HANDLING
// ------------------------------------------------------------------

bot.on('polling_error', e => console.log(chalk.yellow('⚠️ Polling Error:'), e.message));

process.on('unhandledRejection', async (reason, promise) => {
  console.error(chalk.red('🚨 Unhandled Rejection:'), reason);
  for (const adminId of ADMIN_IDS) {
    await safeSendMessage(
      adminId,
      `⚠️ *Unhandled Rejection!*\n\`\`\`${reason?.stack || reason || 'No details'}\`\`\``,
      { parse_mode: 'Markdown' }
    ).catch(() => { });
  }
});

process.on('uncaughtException', async (error) => {
    console.error(chalk.red('🚨 Uncaught Exception:'), error);
    for (const adminId of ADMIN_IDS) {
        await safeSendMessage(
            adminId,
            `🔥 *Uncaught Exception!*\n\`\`\`${error.stack || error.message || 'No details'}\`\`\``,
            { parse_mode: 'Markdown' }
        ).catch(() => { });
    }
    // Lakukan exit setelah notifikasi agar service manager bisa restart
    process.exit(1); 
});

