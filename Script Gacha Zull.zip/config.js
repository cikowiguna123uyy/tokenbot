export default {
  BOT_TOKEN: '8214329795:AAEm5nJ84jLXZ4wE6yICFyWum8yfPCK9Byg',
  BOT_NAME: '𝙱𝚘𝚝 𝚐𝚊𝚌𝚑𝚊 𝚐𝚊𝚋𝚞𝚝 𝚊𝚓𝚊',
  BOT_USERNAME: 'JasherWafa_Bot', 
  CHANNEL_ID: '@wafain',
  OWNER_USERNAME: 'theoneowned', //tanpa @
  ADMIN_IDS: [8153272738], // ID Admin
  GACHA_LIMIT: 5 //mo brp aja bebas
};

// Thank To Buy Script Gacha 